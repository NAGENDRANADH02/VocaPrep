let mediaRecorder;
let audioChunks = [];

const recordBtn = document.getElementById("recordBtn");
const stopBtn = document.getElementById("stopBtn");
const loadingBox = document.getElementById("loadingBox");
const resultsBox = document.getElementById("results");

recordBtn.onclick = async () => {
    audioChunks = [];
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.start();

    recordBtn.disabled = true;
    stopBtn.disabled = false;

    mediaRecorder.ondataavailable = (e) => {
        audioChunks.push(e.data);
    };
};

stopBtn.onclick = () => {
    mediaRecorder.stop();

    recordBtn.disabled = false;
    stopBtn.disabled = true;

    loadingBox.classList.remove("hidden");
};

mediaRecorder.onstop = async () => {
    const blob = new Blob(audioChunks, { type: "audio/webm" });
    const formData = new FormData();
    formData.append("audio", blob);

    const response = await fetch("/analyze/", {
        method: "POST",
        body: formData
    });

    const data = await response.json();

    loadingBox.classList.add("hidden");

    // show results on screen
    resultsBox.classList.remove("hidden");

    document.getElementById("transcriptBox").innerText = data.transcript;
    document.getElementById("feedbackBox").innerText = data.feedback;
    document.getElementById("clarityScore").innerText = data.clarity;
    document.getElementById("confidenceScore").innerText = data.confidence;
    document.getElementById("fillerScore").innerText = data.fillers;
};
