from groq import Groq
from django.conf import settings
import re

client = Groq(api_key=settings.GROQ_API_KEY)

def evaluate_answer(text):
    prompt = f"""
You are an AI interviewer. Analyze the following answer:

{text}

Return the result strictly in this format:

Clarity: <0-10>
Confidence: <0-10>
Filler Words: <number>

Feedback:
<paragraph>
"""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",

        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )

    result = response.choices[0].message.content


    # Extract numbers
    clarity = re.search(r"Clarity:\s*(\d+)", result)
    confidence = re.search(r"Confidence:\s*(\d+)", result)
    fillers = re.search(r"Filler Words:\s*(\d+)", result)

    return {
        "raw": result,
        "clarity": int(clarity.group(1)) if clarity else None,
        "confidence": int(confidence.group(1)) if confidence else None,
        "fillers": int(fillers.group(1)) if fillers else None
    }
