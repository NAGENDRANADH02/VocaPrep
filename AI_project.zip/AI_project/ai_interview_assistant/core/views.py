from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.db import models
from django.urls import reverse
from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str

from .models import InterviewRecord
from .whisper_stt import convert_audio_to_text
from .llm_feedback import evaluate_answer
from .utils import token_generator

# PDF Libraries
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch


# ------------------- HOME PAGE ------------------- #

def homepage(request):
    return render(request, "home.html")


# ------------------- PRACTICE PAGE ------------------- #

@login_required
def index(request):
    return render(request, "index.html")


# ------------------- AUDIO ANALYSIS ------------------- #

@login_required
@csrf_exempt
def analyze_audio(request):
    if request.method == "POST":
        audio_file = request.FILES.get("audio")

        if not audio_file:
            return JsonResponse({"error": "No audio file received"}, status=400)

        transcript = convert_audio_to_text(audio_file)
        result = evaluate_answer(transcript)

        # Save interview record
        InterviewRecord.objects.create(
            user=request.user,
            transcript=transcript,
            feedback=result["raw"],
            clarity_score=result["clarity"],
            confidence_score=result["confidence"],
            filler_words=result["fillers"],
        )

        return JsonResponse({
            "transcript": transcript,
            "feedback": result["raw"],
            "clarity": result["clarity"],
            "confidence": result["confidence"],
            "fillers": result["fillers"],
        })

    return JsonResponse({"error": "Invalid request method"}, status=400)


# ------------------- DASHBOARD ------------------- #

@login_required
def dashboard(request):
    records = InterviewRecord.objects.filter(user=request.user).order_by("-created_at")
    return render(request, "dashboard.html", {"records": records})


# ------------------- REGISTER ------------------- #

def register_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        if User.objects.filter(username=email).exists():
            messages.error(request, "Email already exists")
            return redirect("/register/")

        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
        )

        user.is_active = False
        user.save()

        # Generate verification link
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        token = token_generator.make_token(user)
        link = request.build_absolute_uri(
            reverse("verify_email", kwargs={"uidb64": uid, "token": token})
        )

        # Send email
        send_mail(
            subject="Verify Your Email - AI Interview Assistant",
            message=f"Click the link to verify your email:\n\n{link}",
            from_email="noreply@aiassistant.com",
            recipient_list=[email],
            fail_silently=False,
        )

        messages.success(request, "Verification email sent! Check your inbox.")
        return redirect("/verify-sent/")

    return render(request, "register.html")


# ------------------- LOGIN ------------------- #

def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        user = authenticate(username=email, password=password)

        if user is not None:
            if not user.is_active:
                messages.error(request, "Please verify your email before logging in.")
                return redirect("/login/")

            login(request, user)
            messages.success(request, "Logged in successfully!")
            return redirect("/app/")
        else:
            messages.error(request, "Invalid email or password")
            return redirect("/login/")

    return render(request, "login.html")


# ------------------- LOGOUT ------------------- #

def logout_view(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect("/")


# ------------------- EMAIL VERIFICATION ------------------- #

def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except:
        user = None

    if user is not None and token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        messages.success(request, "Email verified successfully! You can now log in.")
        return redirect("/login/")
    else:
        return render(request, "verified_fail.html")


def verify_sent_page(request):
    return render(request, "verify_sent.html")


# ------------------- PROFILE ------------------- #

@login_required
def profile_view(request):
    user = request.user

    records = InterviewRecord.objects.filter(user=user)
    total = records.count()

    avg_clarity = records.aggregate(avg=models.Avg("clarity_score"))["avg"] or 0
    avg_confidence = records.aggregate(avg=models.Avg("confidence_score"))["avg"] or 0
    total_fillers = records.aggregate(sum=models.Sum("filler_words"))["sum"] or 0

    context = {
        "user": user,
        "total": total,
        "avg_clarity": round(avg_clarity, 2),
        "avg_confidence": round(avg_confidence, 2),
        "total_fillers": total_fillers,
    }

    return render(request, "profile.html", context)


# ------------------- DELETE RECORD ------------------- #

@login_required
def delete_record(request, pk):
    record = get_object_or_404(InterviewRecord, id=pk, user=request.user)
    record.delete()
    messages.success(request, "Record deleted successfully!")
    return redirect("/dashboard/")


# ------------------- DOWNLOAD PDF ------------------- #

@login_required
def download_pdf(request, pk):
    record = get_object_or_404(InterviewRecord, id=pk, user=request.user)

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="interview_{record.id}.pdf"'

    doc = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    content = []

    title = f"Interview Report - {record.created_at.strftime('%Y-%m-%d %H:%M')}"
    content.append(Paragraph(f"<b>{title}</b>", styles["Title"]))
    content.append(Spacer(1, 0.2 * inch))

    details = f"""
        <b>Clarity Score:</b> {record.clarity_score}/10<br/>
        <b>Confidence Score:</b> {record.confidence_score}/10<br/>
        <b>Filler Words:</b> {record.filler_words}
    """
    content.append(Paragraph(details, styles["Normal"]))
    content.append(Spacer(1, 0.3 * inch))

    content.append(Paragraph("<b>Transcript:</b>", styles["Heading2"]))
    content.append(Paragraph(record.transcript.replace("\n", "<br/>"), styles["Normal"]))
    content.append(Spacer(1, 0.3 * inch))

    content.append(Paragraph("<b>AI Feedback:</b>", styles["Heading2"]))
    content.append(Paragraph(record.feedback.replace("\n", "<br/>"), styles["Normal"]))

    doc.build(content)
    return response
