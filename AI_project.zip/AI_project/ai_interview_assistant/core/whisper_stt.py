from groq import Groq
from django.conf import settings

client = Groq(api_key=settings.GROQ_API_KEY)

def convert_audio_to_text(file):
    audio_bytes = file.read()

    response = client.audio.transcriptions.create(
        model="whisper-large-v3",
        file=("audio.webm", audio_bytes)
    )

    return response.text

