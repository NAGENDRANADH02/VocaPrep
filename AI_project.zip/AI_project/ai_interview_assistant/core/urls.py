from django.urls import path
from . import views

urlpatterns = [

    # ---------- Public ----------
    path("", views.homepage, name="home"),

    # ---------- Auth ----------
    path("register/", views.register_view, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),

    # ---------- Email Verification ----------
    path("verify-email/<uidb64>/<token>/", views.verify_email, name="verify_email"),
    path("verify-sent/", views.verify_sent_page, name="verify_sent"),

    # ---------- App Functionality ----------
    path("app/", views.index, name="app"),
    path("analyze/", views.analyze_audio, name="analyze_audio"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.profile_view, name="profile"),

    # ---------- PDF Download ----------
    path("download/<int:pk>/", views.download_pdf, name="download_pdf"),

    # ---------- Delete Record ----------
    path("delete/<int:pk>/", views.delete_record, name="delete_record"),
]
