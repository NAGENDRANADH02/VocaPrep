from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.core.mail import send_mail
from django.conf import settings
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator

def register(request):
    if request.method == "POST":
        email = request.POST["email"]
        password = request.POST["password"]

        if User.objects.filter(username=email).exists():
            messages.error(request, "User already exists!")
            return redirect("register")

        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            is_active=False    # IMPORTANT — user inactive until email verified
        )

        send_verification_email(request, user)

        return render(request, "verify_sent.html", {"email": email})

    return render(request, "register.html")


def send_verification_email(request, user):
    token = default_token_generator.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))

    verification_link = request.build_absolute_uri(f"/verify-email/{uid}/{token}/")

    subject = "Verify your Email - AI Interview Assistant"
    message = f"Click the link to verify your email:\n\n{verification_link}"

    send_mail(subject, message, settings.EMAIL_HOST_USER, [user.email])


def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except:
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        return render(request, "verify_success.html")
    else:
        return render(request, "verify_failed.html")


def login_user(request):
    if request.method == "POST":
        email = request.POST["email"]
        password = request.POST["password"]

        user = authenticate(username=email, password=password)

        if user is None:
            messages.error(request, "Invalid credentials")
            return redirect("login")

        if not user.is_active:
            messages.error(request, "Email not verified!")
            return redirect("login")

        login(request, user)
        return redirect("home")

    return render(request, "login.html")
