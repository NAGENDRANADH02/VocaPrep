from django.db import models
from django.contrib.auth.models import User

class InterviewRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="interviews")
    transcript = models.TextField()
    feedback = models.TextField()
    clarity_score = models.IntegerField()
    confidence_score = models.IntegerField()
    filler_words = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.created_at}"
